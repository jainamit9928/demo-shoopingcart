import React from 'react'
import PropTypes from 'prop-types'

const InputSearch = (props) => (
        <div className='form-inline'>
                <div className='form-group'>
                    <input type='text' className='form-control' value={ props.searchKey } onChange={ (e) => props.filterProducts(e.target.value) }/>
                </div>
         </div>
)

InputSearch.propTypes = {
   setSearchKey: PropTypes.func.isRequired,
   searchKey: PropTypes.string,
  }
export default InputSearch
