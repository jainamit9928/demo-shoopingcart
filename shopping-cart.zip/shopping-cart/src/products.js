const store = {
  
  products : [

  {
    "name": "Apple",
    "id": 1,
    "price": 150,
    "totalquantity": 43
  }, {
    "name": "Orange",
    "id": 2,
    "price": 60,
    "totalquantity": 33
  }, {
    "name": "Pear",
    "id": 3,
    "price": 62,
    "totalquantity": 27
  },
    {
      "name": "Guvava",
      "id": 4,
      "price": 130,
      "totalquantity": 13
    }
]
}

export default store;
