import React from 'react';
import store from './products';
import Product from './Product';
import InputSearch from './inputsearch';

export default class Cart extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            cart: [],
            products: [],
            searchKey:''
        };
        this.filterProducts = this.filterProducts.bind(this);
    }

    toggleToCart = (e, isDelete) => {
        let id = !isDelete && e.currentTarget.dataset.id && parseInt(e.currentTarget.dataset.id);
        if(isDelete){
            id = e;
        }
        let { cart, products } = this.state;
        let tempCart = [...cart];
        let product = products.filter(product => product.id === id)[0];
        let tempProduct = {...product};
        let status = null;
        tempCart.forEach((product) => {
            let tempProduct = product;
            if (tempProduct.id === id && tempProduct.count > 0) {
                isDelete ? tempProduct.count -= 1 : tempProduct.count += 1
                tempProduct.totalquantity -= 1;
                if(tempProduct.count === 0){
                    tempCart = tempCart.filter( product => !(product.id === id) );
                }
                status = 'added';
            }
            return tempProduct;
        });
        if (!(status) && !isDelete) {
            tempProduct.count = 1;
            tempCart.push(tempProduct);
        }
        this.setState({
            cart: tempCart
        })

    }

    componentDidMount() {
        this.setState({
            products: store.products
        })
    }

    filterProducts(searchKey){
        let filteredProducts = store.products.filter(product => product.name.toLowerCase().includes(searchKey.toLowerCase()));
        let newProducts = searchKey === '' ? store.products : filteredProducts;
        this.setState({
            products:newProducts,
            searchKey:searchKey
        })
    }

    render() {
        let { products, cart } = this.state;
        let productkeys = products && products.length > 0 && Object.keys(products[0]);
        return (
            <div className="container">
              
                <div className="products">
                <InputSearch searchKey = {this.state.searchKey} filterProducts={this.filterProducts}/>
                    {
                        <div className="header">
                            
                            <div className="row">
                                {
                                    productkeys && productkeys.map((key) => {
                                        return (
                                            <div class="col">
                                                {key.toUpperCase()}
                                            </div>
                                        )
                                    })
                                }
                            </div>
                        </div>
                    }


                    {
                        <div className="body">
                            {products.map((productDetail) => {
                                return (<Product {...productDetail} key={productDetail.id} toggleToCart={this.toggleToCart} />)
                            })
                            }
                        </div>
                    }

                </div>
                <div className="cart">
                    {
                        cart.map((product) => {
                            return (
                                <CartDetail {...product} toggleToCart = {this.toggleToCart} />
                            )
                        })
                    }

                </div>
            </div>
        )

    }


}

const CartDetail = (props) => {
    return(
        <div className="row" id={props.id}>
        <div className="col">
            {
                props.name
            }
        </div>
        <div className="col">
            {
                props.count
            }
        </div>
        <div className="col">
          <button className="btn" onClick={(e) => props.toggleToCart(props.id, true)}>delete</button>
        </div>
        </div>
    )
}