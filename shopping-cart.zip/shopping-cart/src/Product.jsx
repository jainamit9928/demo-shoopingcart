import React from 'react';

const Product = (props) => {
return(
        <div className="row" data-id={props.id} onClick={props.toggleToCart}>
            <div className="col">
                {
                    props.name
                }
            </div>
            <div className="col">
                {
                    props.id
                }
            </div>
            <div className="col">
                {
                    props.price
                }
            </div>
            <div className="col">
                {
                    props.totalquantity
                }
            </div>
            <div className="col">
            {
                props.count
            }
            </div>
            <button className="btn" >
                addToCart
            </button>

        </div>
)
}

export default Product;
